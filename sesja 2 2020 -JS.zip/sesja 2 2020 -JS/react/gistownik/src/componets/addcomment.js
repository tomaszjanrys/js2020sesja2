import React from 'react'
import Container from 'react-bootstrap/Jumbotron'
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import Table from 'react-bootstrap/Table';
import InputGroup from 'react-bootstrap/InputGroup';
import FormControl from 'react-bootstrap/FormControl'
import Card from 'react-bootstrap/Card'
import Form from 'react-bootstrap/FormControl'
import Api from './gistr'
const token = 'dd4f76fd1b20472a869534a2b2d2c438746e5ac7'
const mojeA = new Api(token)

export default class Addcomment extends React.Component{
  constructor(props){
    super(props)
    this.state = {
      opisT:'Id Gista...',
      contents:'Twoj komentarz',
      id:''

    }
  this.handleChange = this.handleChange.bind(this);
  this.getID = this.getID.bind(this)
  this.butonClickSend2 = this.butonClickSend2.bind(this)
  this.handleChange2 = this.handleChange2.bind(this);

  }
  zmiana = (e)=>{
    this.setState({
      id : e.target.value
    })
  }
//pobiera id  gista z api
  getID(){
    let x = this.state.id
    mojeA.getGist(x)
    .then((res)=>{
      this.setState({
        id: res.data[`${x}`].id,
        content: res.data[`${x}`].description
      })
    })
  .catch((err)=>{
    alert('Sorry coś poszło nie tak...')
  })
  }
  // epobiera id  gista z api//
  butonClickSend2(event){
    event.preventDefault()
    let id = this.state.id
    let contents = this.state.contents

    mojeA.addComment(id, contents)


  }
  handleChange(event) {

    this.setState({ opisT: event.target.value });
  }
  handleChange2(event) {

    this.setState({ contents: event.target.value });

  }

  render(){
    return(
      <div>
      <Container>
      <hr/>
      <InputGroup >


      <InputGroup.Prepend >
  <Button variant="outline-warning" size='sm' onClick={this.getID}> Nr Gista ..np. 1..  </Button>
      <FormControl  aria-describedby="basic-addon1" value={this.state.id} onChange={this.zmiana}/>
      </InputGroup.Prepend>
      <FormControl as="textarea" aria-label="With textarea" value={this.state.contents}
      onChange={this.handleChange2}/>
      <Button variant="outline-success" size='sm' onClick={this.butonClickSend2}> komentarz </Button>


      </InputGroup>
      <hr/>

      </Container>
      </div>
    )
  }

}
