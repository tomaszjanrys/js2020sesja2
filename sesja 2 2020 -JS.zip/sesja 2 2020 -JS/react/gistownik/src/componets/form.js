import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import InputGroup from 'react-bootstrap/InputGroup';
import Button from 'react-bootstrap/Button';
import FormControl from 'react-bootstrap/FormControl'
import '../css/App.css';
export default class Form extends React.Component {
//uwaga  onSubmit zostal zmieniony na onClick
render(){
return(
<div >
<InputGroup className="mb-3" size='sm'  >
    <InputGroup.Prepend >
      <Button variant="outline-warning" size='sm' onClick={this.props.sub}> Sprawdź  </Button>
    </InputGroup.Prepend>
    <FormControl className='mb-3a' aria-describedby="basic-addon1" value={this.props.stateValue} onChange={this.props.changeInputNew} />
  </InputGroup>
</div>

)


}
}
