import React from 'react'

import Container from 'react-bootstrap/Jumbotron'
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import Table from 'react-bootstrap/Table';
import InputGroup from 'react-bootstrap/InputGroup';
import FormControl from 'react-bootstrap/FormControl'
import Form from 'react-bootstrap/FormControl'
import Api from './gistr'

const token = 'dd4f76fd1b20472a869534a2b2d2c438746e5ac7'
const mojeA = new Api(token)   

export default class Gistedit extends React.Component{
  constructor(props){
    super(props)
    this.state = {
      opisT:'Opisz gista...',
      content:'Tresc gista',

    }
 
    this.butonClickSend = this.butonClickSend.bind(this)

    this.handleChange = this.handleChange.bind(this);

    this.handleChange2 = this.handleChange2.bind(this);
  }
  
  handleChange(event) {
   
    this.setState({ opisT: event.target.value });
  }
  handleChange2(event) {
   
    this.setState({ content: event.target.value });
    
  }
  //handleDel(event) {
   // event.preventDefault()
   // this.setState({ del: event.target.del });
    
  //}

  butonClickSend(event){
    event.preventDefault()
    let opisTT = this.state.opisT
    let opisC = this.state.content
    
    mojeA.postRequest(opisTT, opisC)
  
 
  }

 
render(){
    return(
        <Container>
<hr/>           
    <InputGroup >


    <InputGroup.Prepend >
  
      
      <FormControl  aria-describedby="basic-addon1" value={this.state.opisT}  onChange={this.handleChange}/>
    </InputGroup.Prepend>
    <FormControl as="textarea" aria-label="With textarea" 
     value={this.state.content}
     onChange={this.handleChange2}
       
     />
     <Button variant="outline-success" size='sm' onClick={this.butonClickSend} > Send Gist </Button>
    
 
  </InputGroup>
  <hr/>

        </Container>
    )
}
} 