import React from 'react'
import Container from 'react-bootstrap/Jumbotron'
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import Table from 'react-bootstrap/Table';
import InputGroup from 'react-bootstrap/InputGroup';
import FormControl from 'react-bootstrap/FormControl'
import Card from 'react-bootstrap/Card'
import Form from 'react-bootstrap/FormControl'
import Api from './gistr'
const token = 'dd4f76fd1b20472a869534a2b2d2c438746e5ac7'
const mojeA = new Api(token)  
export default class Updategist extends React.Component {
  constructor(props){
    super(props)
    this.state ={
      id : '',
      content :''
    }
this.getID = this.getID.bind(this)
this.zmiana = this.zmiana.bind(this)
  }
  zmiana = (e)=>{
    this.setState({
      id : e.target.value
    })
  }
getID(){
  let x = this.state.id
  mojeA.getGist(x)
  .then((res)=>{
    this.setState({
      id: res.data[`${x}`].id,
      content: res.data[`${x}`].description
    })
  })
.catch((err)=>{
  alert('Sorry coś poszło nie tak...')
})
}


    render(){
        return(
           <Container className='containerUpdate'>
               <Row sm='2'>
               <Col>
               <InputGroup className="inputNrGist" size='sm'  >
    <InputGroup.Prepend >
      <Button variant="outline-warning" size='sm'  onClick={this.getID}> Pobierz Gista...  </Button>
    </InputGroup.Prepend>
    <FormControl  aria-describedby="basic-addon1" placeholder="NR GISTA do edycji....." value={this.state.id} onChange={this.zmiana} />
  </InputGroup>
               
  <br/><br/><br/>
               <Card border="success" style={{ width: '18rem' }}>
					<Card.Header><b>ID</b> {this.state.id}</Card.Header>
					<Card.Body>
						<Card.Title>Zawartość GISTA</Card.Title>
						<Card.Text>
						{this.state.content}
      </Card.Text>
					</Card.Body>
				</Card>
               </Col>
               <Col>
               <InputGroup >


<InputGroup.Prepend >

  
 
</InputGroup.Prepend>
<FormControl as="textarea" aria-label="With textarea"/>
 <Button variant="outline-danger" size='sm' > Update Content </Button>
</InputGroup>




               </Col>

               </Row>
           </Container>
        )
    }
}