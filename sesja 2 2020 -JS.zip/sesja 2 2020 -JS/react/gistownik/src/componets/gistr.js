
const axios = require('axios')
 export default class Api {
    constructor(token){
        this.token = token
        this.client = axios.create({
            baseURL: 'https://api.github.com/',
            responseType: 'json',
            headers: {
                'Accept': 'application/vnd.github.v3+json',
                'Authorization': 'token ' +this.token
         }

    })

}
addComment(id,contents){
  return this.client.post(`/gists/${id}/comments`,{
    "body":`${contents}`
  })
  .then(function(res){
        if (res.status === 201){
            return alert("Komentasz dodany ;).....:)")
        }
      })
  .catch(function(err){
      if (err){
          alert('Coś poszło nie TAK ;(')
      }

    })
}
//pobieranie gista
getGist(gistID) {
    return this.client(`/users/tomaszjanrys/gists`)
}
//end pobierania
//tworzenie gista
postRequest(opisTT,opisC) {
    return this.client.post('/gists', {
        "description": `${opisTT}`,
        "public": true,
        "files": {
            "hello_world.html": {
                "content": `${opisC}`
            }
        }

    })
    .then(function(res){
          if (res.status === 201){
              return alert("Gist został utworzony.....:)")
          }
        })
    .catch(function(err){
        if (err){
            alert('Coś poszło nie TAK ;(')
        }

      })

}
deleteGist(gistId) {//kasowanie
    return this.client.delete(`/gists/${gistId}`)
}
//edycja gista
updateGist(idG){
//this.client.get('/users/tomaszjanrys/gists')
//.then(function(res){
//    this.c = res.data[`${idG}`].id
//    console.log(res.data[`${idG}`].description)

this.client.patch(`/gists/${this.c}`, {
    "description": 'Update 3'
    } )
.then(function(res){
    console.log(res.status)
    this.client.get('/users/tomaszjanrys/gists')
//.then(function(res){
//    this.c = res.data[`${idG}`].id
//    console.log(res.data[`${idG}`].description)
//end pobranie id gista i desription
//})//end update
})//end pobrania nowego gista
}//end editGIst

}
//end tworznia//////
//kasowanie gista
