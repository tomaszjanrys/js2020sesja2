import React from 'react';
import '../css/App.css';

class Testc extends React.Component  {
    constructor(props){
super(props)
this.paint = this.paint.bind(this);
    }
 
    componentDidUpdate(){
        this.paint()
    }
    paint() {
        const x = document.getElementById('createCanvas')
        x.width = 800;
        x.height = 300
        document.body.appendChild(x)
        const ctx = this.refs.canvasS.getContext('2d')
        let kwadrat = {
            x : this.x.width / 2 ,
            y : this.x.height / 2 ,
            h : this.rand(10,100),
            r: this.rand(0, 240),
            g: this.rand(0, 240),
            b: this.rand(0, 240),
            speedX: this.rand(-1000, 1000) / 100,
            speedY: this.rand(-1000, 1000) / 100

        }
      
    
     
    
            ctx.fillStyle = 'rgba(142,144,114,0.2)';
            ctx.fillRect(0, 0, x.width, x.height);
            ctx.fillStyle = 'rgb(' + kwadrat.r + ',' + kwadrat.g + ',' + kwadrat.b+')';
            kwadrat.x = kwadrat.x + kwadrat.speedX;//kwadrat to jest obiekt z przypisanym kluczem ktory ma ustalona wartosc 
            kwadrat.y = kwadrat.y + kwadrat.speedY;
            ctx.fillRect(kwadrat.x - kwadrat.h / 2, kwadrat.y - kwadrat.h / 2, kwadrat.h, kwadrat.h);
       
  
        
      }
      
render(){
    return(
        <div>
     <canvas id = "createCanvas" ref = "canvasS"> </canvas>
        </div>
    )
}
}

export default Testc