import React from 'react';
import Gistread from './gistread';
import Gistedit from './editgist';
import Updategist from './updategist';
import Addcomment from './addcomment';
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';
import {BrowserRouter as Router, Switch, Route,Link } from "react-router-dom";


export default class Menu extends React.Component{
    render(){
        return(
            <div>
            <Router>
              <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
  <Navbar.Brand href="#home">Gistownik-API</Navbar.Brand>
  <Navbar.Toggle aria-controls="responsive-navbar-nav" />
  <Navbar.Collapse id="responsive-navbar-nav">
    <Nav className="mr-auto">
      <Nav.Link href="/gist" to="/gist">Czytaj gisty </Nav.Link>
      <Nav.Link href="/editgist" to="/editgist">Utwórz Gista</Nav.Link>
      <Nav.Link href="/updategist" to="/updategist">Update Gist</Nav.Link>
      <Nav.Link href="/add">Dodaj komentarz </Nav.Link>

    </Nav>

  </Navbar.Collapse>
</Navbar>
 <Switch>
                        <Route path="/gist">
                            <Gistread />
                        </Route>
                        <Route path="/editgist">
                            <Gistedit />
                        </Route>
                        <Route path="/updategist">
                            <Updategist />
                        </Route>
                        <Route path="/add">
                            <Addcomment />
                        </Route>

                    </Switch>
</Router>
            </div>
        )
    }
}
