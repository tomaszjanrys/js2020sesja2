import React from 'react'
import Container from 'react-bootstrap/Jumbotron'
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import Table from 'react-bootstrap/Table';
import InputGroup from 'react-bootstrap/InputGroup';
import FormControl from 'react-bootstrap/FormControl'
import Api from './gistr'
const token = '26de5393aa2a4d5e21510af5f81bd6542c3f3950'
const moje = new Api(token) 
const mojeA = new Api(token)  
 
export default class Gistread extends React.Component{
    constructor(props){
        super(props)
    this.state = {
        status: '',
        idgista: '',
        opis:'',
        adres:'',
        file:'',
        del:''
    }
    this.buttonOnclick=this.buttonOnclick.bind(this)
    this.butonClickDel = this.butonClickDel.bind(this)

}
  buttonOnclick(e){
e.preventDefault()
      moje.getGist()
      .then(function(res){
          if (res.status === 200){
              return res
          }
        
      })
      .then(res=>{
          this.setState({
              idgista:res.data[0].id,
              opis:res.data[0].description,
              status:res.status,
              adres:res.data[0].git_pull_url,
              file:res.data[0].owner.login,
              idgista2:res.data[1].id,
              opis2:res.data[1].description,
              idgista3:res.data[2].id,
              opis3:res.data[2].description,
          
          

          })

      })
    .catch(err=>console.log(err))
      

  }
  butonClickDel(event){
    event.preventDefault()
    console.log(this.state.del)
    mojeA.deleteGist(this.state.del)
    }
    handleDel = (event) =>{
      this.setState({
          del: event.target.value//e to nowa wartosc wpisana w inpucie
      })
  }
    render(){
        return(
          <Container className="tabela">
          <Row xs='1'>
          <Col>
          <span className="text-info">Status :</span>
          <span className="status-gist">{this.state.status}</span>
          <span className="text-info"> Adres</span> : <span className="adres-gist"> <a href={this.state.adres}>Strona gista</a></span>
          <hr/>
          <InputGroup  size='sm'  >
    <InputGroup.Prepend >
      <Button variant="info" size='sm' > Send  </Button>
    </InputGroup.Prepend>
    <FormControl  aria-describedby="basic-addon1" placeholder="Wklej swojego TOKENA"/>
  </InputGroup>
          <hr/>
                  <Button variant="warning" onClick={this.buttonOnclick}>Pobierz gista</Button>
                
                  
                 
              <hr/>
                  </Col>
                  <Col>
                  <Table striped bordered hover>
  <thead>
    <tr>
      <th>Nr Gista</th>
      <th>ID GISTA</th>
      <th>Opis</th>
      <th>Login</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0 - Najnowszy gist</td>
      <td >{this.state.idgista}</td>
      <td>{this.state.opis}</td>
      <td>{this.state.file}</td>
    </tr>
    <tr>
      <td>1</td>
      <td>{this.state.idgista2}</td>
      <td>{this.state.opis2}</td>
      <td>{this.state.file}</td>
    </tr>
    <tr>
    <td>2</td>
      <td>{this.state.idgista3}</td>
      <td>{this.state.opis3}</td>
      <td>{this.state.file}</td>
    </tr>
  </tbody>
</Table>
              
                  </Col>
                  </Row>
                  <hr/>
                  <InputGroup  size='sm'  >
    <InputGroup.Prepend >
      <Button variant="outline-danger" size='sm' onClick={this.butonClickDel}> Usuń Gista  </Button>
    </InputGroup.Prepend>
    <FormControl  aria-describedby="basic-addon1"  placeholder="Wklej ID gista .........." value={this.state.pole} onChange={this.handleDel}/>
  </InputGroup>
          </Container>  
        )
    }
}