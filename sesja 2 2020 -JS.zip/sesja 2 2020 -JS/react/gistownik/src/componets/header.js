import React from 'react'
import Jumbotron from 'react-bootstrap/Jumbotron';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container'
import Form from './form'
import Results from './results'
import '../css/App.css';
import logo from '../jpg/sun.png'
import axios from 'axios'
import Menu from './Menu'
const apikey = '11a1c782fea77ec7ca2026ac55229d55'//klucz
const api = axios.create({
    baseURL: `http://api.openweathermap.org/`

})
const liveTime2 = new Date().toLocaleDateString()
const liveTime1 = new Date().toLocaleTimeString()
export default class Header extends React.Component {
  
    state = {//stala wartosc nie zmienia sie
        
        value: "Tychy",//wartosc wyswietlanna w inpucie
        date: liveTime2,
        time: '----',
        city:'----',
        sunrise: '----',
        sunset: '----',
        temp:'----',
        pressure:'----',
        wind:'----',
        humidity:'----',
        clouds:'----',
        weatherinfo1:'----',
        weatherinfo2:'----',
        err: 'Brak miasta w bazie',

    }
    //metoda ktora zmienia state inputa dostaje wratosc przekazuje ja do value nastepnie kompoent jest renderowany od nowa
    changeInput = (e) =>{
        this.setState({
            value: e.target.value//e to nowa wartosc wpisana w inpucie
        })
    }
   
    //metoda do oblugi wysylania danych z axios
    handleCitySub = (e) =>{
        
 e.preventDefault()
    api.get(`/data/2.5/weather?q=${this.state.value}&appid=${apikey}&units=metric`)
    .then(response =>{
        if(response.status === 200){
            console.log(response.data)
            return response
        }
    })
    //resp zawiera opd return przekazuje data aby dostatc sie do kluczy data
    .then(response =>{return response.data})
    .then(data=>{
        
        this.setState({
            err: false,
            time: liveTime1,
            city: this.state.value,
            sunrise: new Date(data.sys.sunrise * 1000).toLocaleTimeString(),
            sunset: new Date(data.sys.sunset * 1000).toLocaleTimeString(),
            temp: data.main.temp,
            humidity: data.main.humidity,
            pressure: data.main.pressure,
            wind: data.wind.speed,
            weatherinfo1: data.weather[0].main,
            weatherinfo2: data.weather[0].description
          
        })
    })
    .catch(err =>{
        console.log('NIe mam takiego miasta');
        this.setState({
            err: true,
            city: this.state.err
        })
    })
    }
   
    render(){
       
        return(
        <Container>
        
       
            <Jumbotron  className='Jumbo'>
            <b><h5 className='h5'>Pogodynka - React.js , Axios, Bootstrap,  sesja 2.0 czas</h5> 
            <p className="liveTime">{this.state.date}
            <p className="Time2">{this.state.time}</p>
            </p></b>
            <img src={logo} alt="Logo" className="sunP"/>

            <hr/>
            <b></b>
         
            <Form className="Form"
            stateValue={this.state.value} 
            changeInputNew={this.changeInput}
            sub={this.handleCitySub} 
          
            />
        
           <br/>
       
           
          <Results pogoda = {this.state} 
         // errSend={this.state.err}
          // czas={this.state.date} 
          // wiatr={this.state.wind}  
          /></Jumbotron>
          <Menu/> 
          <div className="footer">www.ncov19.pl 2020</div>
          
        </Container>
             
        )
        }       
}