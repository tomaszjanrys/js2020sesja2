import React from 'react';
import '../css/App.css';
import Container from 'react-bootstrap/Jumbotron'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import wind from '../jpg/wind.png'
import sunrise from '../jpg/sunrise.png'
import sunset from '../jpg/sunset.png'
import temp from '../jpg/temp.png'

import press from '../jpg/pressure.png'

export default class Results extends React.Component {

  render(){
        return(
        <div>
        <Container className="resultsContainer">
        <span className="infoCity">
        {this.props.pogoda.city}  :
      <span className="humidityTextCSS"> Wilgotność : {this.props.pogoda.humidity} %</span>
      <span className="humidityTextCSS"> Info : {this.props.pogoda.weatherinfo1} </span>
      <span className="humidityTextCSS"> , {this.props.pogoda.weatherinfo2} </span>
      
        </span>

        <hr/>
      <Row xs="5">
        <Col>
        <span className="sunriseCSS">
        <img src={sunrise} alt="Logo" className="sunriseCSS"/>
        </span>
        <p className="textGetDataCSS">{this.props.pogoda.sunrise}</p>
            
      
        </Col>
        <Col>
        
        <span className="sunsetCSS">
        <img src={sunset} alt="Logo" className="sunsetCSS"/>
       </span>
       <p className="textGetDataCSS">{this.props.pogoda.sunset}</p>
        </Col>
        <Col>
   
        <img src={temp} alt="Logo" className="tempCSS"/>
      
        <p className="textGetDataCSS" >
        {this.props.pogoda.temp} &#176;C
        </p></Col>
  
        <Col>  <img src={wind} alt="Logo" className="windCSS"/>
        <p className="textGetDataCSS">  {this.props.pogoda.wind} M/s</p></Col>
        <Col>
        <img src={press} alt="Logo" className="presCSS"/>
       <p className="textGetDataCSS">{this.props.pogoda.pressure} Hpa</p>
        </Col>
     
     
      

      </Row>
  
    </Container>
        </div>
        
        )
        }       
}